<?php echo $view['form']->block($form, 'form_widget_simple', ['type' => $type ?? 'password']) ?>

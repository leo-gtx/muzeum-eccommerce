<?php

namespace Gedmo\Mapping\Annotation;

/**
 * @Annotation
 */
class ReferenceManyEmbed extends Reference
{
}

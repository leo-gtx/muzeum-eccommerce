CHANGELOG
=========

4.4.0
-----

 * [BC BREAK] Renamed and moved `Symfony\Component\Mailer\Bridge\Google\Smtp\GmailTransport`
   to `Symfony\Component\Mailer\Bridge\Google\Transport\GmailSmtpTransport`.

4.3.0
-----

 * Added the bridge

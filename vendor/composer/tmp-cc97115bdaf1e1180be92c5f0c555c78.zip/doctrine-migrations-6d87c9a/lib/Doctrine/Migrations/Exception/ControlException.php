<?php

declare(strict_types=1);

namespace Doctrine\Migrations\Exception;

interface ControlException extends MigrationException
{
}

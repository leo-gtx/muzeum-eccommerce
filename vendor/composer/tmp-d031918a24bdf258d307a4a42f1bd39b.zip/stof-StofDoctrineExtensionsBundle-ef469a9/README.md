# StofDoctrineExtensionsBundle

This bundle provides integration for
[DoctrineExtensions](https://github.com/Atlantic18/DoctrineExtensions) in
your Symfony Project.

[![Total Downloads](https://poser.pugx.org/stof/doctrine-extensions-bundle/downloads.png)](https://packagist.org/packages/stof/doctrine-extensions-bundle)
[![Latest Stable Version](https://poser.pugx.org/stof/doctrine-extensions-bundle/v/stable.png)](https://packagist.org/packages/stof/doctrine-extensions-bundle)

For documentation, see it [online](https://symfony.com/doc/master/bundles/StofDoctrineExtensionsBundle/index.html)

License: [MIT](LICENSE)
